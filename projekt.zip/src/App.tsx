import './App.css'
import Home from "./components/home.tsx";
import RenderNumbers from "./components/render-numbers.tsx";
import React, {useEffect} from "react";
import axios from "axios";

function App() {

    const data = [50, 60, 70 , 80];

    const [basicNumber, setBasicNumber] = React.useState(10);
    const [meal, setMeal] = React.useState({});

    function plusOne() {
        setBasicNumber(basicNumber + 1);
    }


    async function getMealResponse() {
        const mealResponse = await axios.get('https://www.themealdb.com/api/json/v1/1/random.php');
        setMeal(mealResponse.data.meals[0]);
    }

    useEffect(()=>{
       getMealResponse()
    },[])

    return (
        <>
            <Home/>
            <RenderNumbers numbers={data} jadu="this is jadu text"/>
            {basicNumber} <button onClick={plusOne}>Press to +1</button>

            <img src="https://picsum.photos/200/300" alt="google logo"/>
            {Object.keys(meal).length !== 0 && Object.keys(meal).map((key, index) => {
                return <div key={index}>{key} : {meal[key]}</div>
            }
            )}
            {meal.strMealThumb && <img src={meal.strMealThumb} alt="meal"/>}
        </>
    )
}

export default App
