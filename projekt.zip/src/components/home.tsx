
const Home =()=> {
    return <div id="home">
        <h1>Hello World</h1>
    </div>
}

export default Home