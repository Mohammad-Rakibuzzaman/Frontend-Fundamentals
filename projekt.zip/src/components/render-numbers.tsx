import React from "react";

const RenderNumbers = (props) => {
    const numbers = props.numbers
    const jadu = props.jadu
    return <>
        <div>{jadu}</div>
        {numbers.map(
            (n, index) => {
                return <SoloNumber key={index} number={n}/>
            })}
    </>
}

const SoloNumber = ({number}) => {

    const [basicSoloNumber, setBasicSoloNumber] = React.useState(number);

    function plusOneBasicNumber() {
        setBasicSoloNumber(basicSoloNumber + 1);
    }

    return <div >{basicSoloNumber} <button onClick={plusOneBasicNumber}>+1</button>
    </div>
}

export default RenderNumbers